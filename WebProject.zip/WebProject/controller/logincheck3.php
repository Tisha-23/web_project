<?php
	session_start();
	require('../model/userModel.php');
	if(isset($_POST['submit'])){
	//	$usertype = $_REQUEST['usertype'];
		$username = $_POST['username'];
		$password = $_POST['password'];

		if($username != null && $password != null){

			$status = login($username, $password);
			if($status){
				$_SESSION['status'] = 'true';
				if(isset($_POST['remember']))
				{
					//setcookie('username',$username, time()+3600, '/');
					//setcookie('password',$password, time()+3600, '/');
					$_SESSION['utype'] = $usertype;
					$_SESSION['username'] = $username;

				 header('location: ../view/info.php');
				}
				
		}
		else
		{
		echo "invalid credentials!";
		}
	}
}
?>
