<?php
	session_start();
	require("../model/userModel.php") ;

	 if(isset($_POST['submit'])){
		$name =$_POST['name'];
			$email = $_POST['email'];
		$username = $_POST['username'];
		$password = $_POST['pass'];
		
		
		$dob = $_POST['dob'];


		if($name != null && $email != null && $username != null && $password != null && $dob !=null){
    
			$status = signup($name, $email, $username, $password, $dob);


			if($status){
				
				$_SESSION['username'] = $username;
				header('location: ../view/info.php');
			}else{
				header('location: ../view/reg.php');
			}

		}else{
			echo "null submission..";
		}
	}
?>
