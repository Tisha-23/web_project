<?php
session_start();

  include '../model/userModel.php';

  //$data = json_decode(file_get_contents("../model/data.json"), true);
  $data = userdata($_SESSION['username']);
  if($data)
  {
    $_SESSION['name'] = $data['name'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['email'] = $data['email'];
    $_SESSION['gender'] = $data['gender'];
    $_SESSION['dob'] = $data['dob'];
  }
  ?>
