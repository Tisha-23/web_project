<?php
session_start();
require ('../Model/UserModel2.php');
if(isset($_POST['submit']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];
    if($username !=null && $password !=null){
    $status=Login($username,$password);
    if($status)
    {
		$_SESSION['username'] = $username;
        header("Location:../View/info.php");
    }
    else
    {
        echo "Invalid or incomplete action";
    }
}
}

?>