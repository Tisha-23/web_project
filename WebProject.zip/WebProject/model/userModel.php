<?php
//session_start();
function signup($name, $email, $username, $password, $dob)
{

		$current_data = file_get_contents('../model/data.json');
		$array_data = json_decode($current_data, true);
			 $extra = array(
				    'name'        =>   $name,
						'email'          =>  $email,
						'username'     =>     $username,
						'password'     =>     $password,
						
						'dob'    => $dob

			 );

			$array_data[] = $extra;
			$final_data = json_encode($array_data);

			file_put_contents('../model/data.json', $final_data);
			return $final_data;


}

function login($username, $password)
{
	$current_data = file_get_contents('../model/data.json');
	$array_data = json_decode($current_data, true);
//	print_r ($array_data);
	for($i=0;$i<sizeof($array_data);$i++)
	{
		foreach($array_data[$i] as $key => $val)
		{
			if($array_data[$i]['username']==$username && $array_data[$i]['password']==$password)
			return true;
		}

	}
	  //print_r($array_data);


}


function userdata($username)
{

	$data = json_decode(file_get_contents("../model/data.json"), true);

	foreach($data as $user){
	    if($user["username"] === $username){
         // session_start();
					// $_SESSION['username'] = $user["username"];
					// $_SESSION['password'] =$user["password"];
					// $_SESSION['email'] = $user["email"];
					// $_SESSION['dob'] = $user['dob'];
					// $_SESSION['gender'] = $user['gender'];

					return $user;
	        break;
	    }
}
}



 ?>
