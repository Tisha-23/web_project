<?php
include "../controller/logincheck2.php";
$username=$password="";
$nameErr = $passwordErr = "";

if (isset($_SESSION["submit"])){
	$error = false;
	if (empty($_POST["username"])){
		$nameErr = "username is required";
		$error = true;
	}
	if (empty($_POST["password"]))
	{
		$passwordErr = "password is required";
		$error = true;
	}
}
//setcookie("username",$_SESSION["username"],time()+(86400*2),"/");
?>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
        integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="login5.css">
	<title>Login</title>
	
</head>
<body>
<div class="container">
<div class="login-details">
     <div class="header">
        <h1>MSTS Airline</h1>
                <h2>Log In</h2>
            </div>

	<form id="form" method="post" action="">
        
        <div class="username">
            <label for="username">Username<span>*</span></label>
            <input type="text" id="username" name="username" required><?php echo $nameErr; ?>
            <i class="fa-solid fa-circle-check"></i>
            <i class="fa-solid fa-circle-exclamation"></i>
        </div>
        <div class="password">
            <label for="password">Password<span>*</span></label>
            <input type="password" id="password" name="password" required><?php echo $passwordErr; ?>
            <i class="fa-solid fa-circle-check"></i>
            <i class="fa-solid fa-circle-exclamation"></i>
        </div>
         <a href="#" class="forgot-password">Forgot password?</a>
        <button id="submit" type="submit" name="submit" >Login</button>
        <small>Don't have an account?</small>
		<a href="reg.php" class="sign-up">Sign Up</a>
    </form>
    </div>
    <div class="login-img">
            <img src="login-image-2.jpg" alt="login">
        </div>
	
</div>
</body>
</html>