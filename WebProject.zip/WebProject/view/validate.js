function validation()
	{
		const fields = document.querySelectorAll(".validate");

		for(let i =0; i< fields.length ;i++){
		if(fields[i].value == "")
		{
			alert(fields[i].name+" is empty!");
			return false;
		}
	}
}

