-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2022 at 03:40 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `labtask`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Name`, `Email`, `Address`) VALUES
(1, 'tisha', 'tisha@gmail.com', 'house-36,tongi,gazipur'),
(2, 'nisha', 'nisha@gmail.com', 'uttara,dhaka'),
(3, 'tamanna', 'tamanna@gmail.com', 'rampura,dhaka'),
(4, 'sadia', 'sadia@gmail.com', 'C-block,bashundhara'),
(5, 'tanha', 'tanha@gmail.com', 'mirpur');

-- --------------------------------------------------------

--
-- Table structure for table `airhostess`
--

CREATE TABLE `airhostess` (
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `flight_name` varchar(20) NOT NULL,
  `flight_time` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `airhostess`
--

INSERT INTO `airhostess` (`name`, `email`, `flight_name`, `flight_time`) VALUES
('nisha', 'nisha@gmail.com', 'American_airlines', '2022-10-20 09:56:34.000000'),
('rahim', 'rahim@gmail.com', 'Biman_Bangladesh', '2022-11-16 05:39:16.000000'),
('karim', 'karim@gmail.com', 'Qatar_airlines', '2022-10-10 14:22:12.000000'),
('tisha', 'tisha@gmail.com', 'American_airlines', '2022-10-27 11:59:42.000000'),
('sadia', 'sadia546@gmail.com', 'US_Bangla', '2022-08-27 18:00:20.000000'),
('korobi', 'korobi86@gmail.com', 'Qatar_airlines', '2022-08-17 15:01:04.000000'),
('suchi', 'suchi545@gmail.com', 'Emirates', '2022-08-17 15:22:48.000000'),
('zerin', 'zerin20@gmail.com', 'US_Bangla', '2022-08-18 13:05:19.000000');

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `name` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact_number` int(20) NOT NULL,
  `flight_time` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`name`, `email`, `contact_number`, `flight_time`) VALUES
('rima', 'rima@gmail.com', 1764545787, '2022-08-11 07:21:37.000000'),
('tamanna', 'tamanna54@gmail.com', 1764545787, '2022-08-15 14:46:01.000000'),
('tisha', 'tisha@gmail.com', 178765400, '2022-04-13 14:47:19.000000'),
('disha', 'disha@gmail.com', 178765400, '2022-10-14 14:47:51.000000'),
('zerin', 'zerin20@gmail.com', 1764545787, '2022-08-12 15:10:52.000000'),
('yasin', 'yasin43@gmain.com', 1971044222, '2022-10-16 10:31:10.000000'),
('era', 'era888@gmail.com', 1978786543, '2022-12-24 06:25:23.000000'),
('karim', 'karim@gmail.com', 178765400, '2022-08-19 15:12:50.000000'),
('nisha', 'nisha@gmail.com', 1971044227, '2022-08-03 05:25:02.000000'),
('disha', 'disha@gmail.com', 1764545769, '2022-08-11 07:21:37.000000'),
('hasan', 'hasan@gmail.com', 1978786543, '2022-09-04 12:21:31.000000');

-- --------------------------------------------------------

--
-- Table structure for table `passenger_info`
--

CREATE TABLE `passenger_info` (
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` text NOT NULL,
  `Confirm Password` text NOT NULL,
  `DOB` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `passenger_information`
--

CREATE TABLE `passenger_information` (
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `User Name` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Confirm Password` varchar(10) NOT NULL,
  `DOB` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passenger_information`
--

INSERT INTO `passenger_information` (`Name`, `Email`, `User Name`, `Password`, `Confirm Password`, `DOB`) VALUES
('tamanna', 'tamanna@gmail.com', 'tami', 'tam90', 'tam90', '2022-08-11'),
('anika kobir', 'anika45@gmail.com', 'anika', '1234', '1234', '2014-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `pilot`
--

CREATE TABLE `pilot` (
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `schedule` datetime(6) NOT NULL,
  `meeting_schedule` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pilot`
--

INSERT INTO `pilot` (`name`, `email`, `schedule`, `meeting_schedule`) VALUES
('rahim', 'rahim@gmail.com', '2022-09-02 15:27:26.000000', '2022-10-27 09:24:53.000000'),
('karim', 'karim@gmail.com', '2022-09-02 15:27:26.000000', '2022-05-16 11:09:07.000000'),
('hasan', 'hasan@gmail.com', '2022-08-17 11:10:05.000000', '2022-10-27 09:24:53.000000'),
('suchi', 'suchi545@gmail.com', '2022-09-16 01:08:49.000000', '0000-00-00 00:00:00.000000'),
('hasan', 'hasan@gmail.com', '2022-09-16 11:09:45.000000', '2022-10-21 17:16:29.000000');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `salary` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`name`, `email`, `salary`, `address`) VALUES
('Tisha', 'tisha@gmail.com', '50k', 'uttara'),
('nisha', 'nisha@gmail.com', '40k', 'tongi'),
('disha', 'disha@gmail.com', '33k', 'tongi'),
('Sadia', 'sadia@gmail.com', '33k', 'dhanmondi'),
('tamanna', 'tamanna@gmail.com', '23k', 'tongi,gazipur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
