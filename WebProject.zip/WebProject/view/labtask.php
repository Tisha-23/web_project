<html>
<head>
	<link rel="stylesheet" href="after-login.css">
</head>
<body id="body">
<button id="insert">Insert!</button>
<button id="update">Update!</button>
<button id="delete">Delete!</button>
<button id="log-out"><a href="log5.php">Logout</a></button>
<div id='main'>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname="labtask";
$conn=new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	
	$q="SELECT * from Admin";
	$result=$conn->query($q);
	$output='<table border="1" width=100%><tr><th>id</th><th>Name</th><th>Email</th><th>Address</th></tr>';
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			$output.= "<tr><td>{$row["id"]}</td><td>{$row["Name"]}</td><td>{$row["Email"]}</td><td>{$row["Address"]}</td></tr>";
		}
		$output.='</table>';
	}
	else
		echo "O results";
	
	
}
$conn->close();
echo $output;
?>
</div>
	<div id="gen"></div>
	<script src="jquery.js"></script>
	<script>
		$(document).ready(function(e){
			$(document).on('click','#insert',function(e){
				$("#gen").html(
					"<div style='margin-top:20px'><h4>New Entry</h4><form><label>Enter id: </label><input id='id' type='number'><br><label>Enter Name: </label><input id='Name' type='text'><br><label>Enter Email: </label><input id='Email' type='text'><br><label>Enter Address: </label><input id='Address' type='text'><br><button id='Submit'>insert</button></form></div>"
				);
			});
			
			$(document).on('click','#update',function(e){
				$("#gen").html(
					"<div style='margin-top:20px'><h4>Update Entry</h4><form><label>Enter id: </label><input id='id' type='number'><br><label>Enter Name: </label><input id='Name' type='text'><br><label>Enter Email: </label><input id='Email' type='text'><br><label>Enter Address: </label><input id='Address' type='text'><br><button id='updateSubmit'>update</button></form></div>"
				);
			});
			
			$(document).on('click','#delete',function(e){
				$("#gen").html(
					"<div style='margin-top:20px'><h4>Delete Entry</h4><form><label>Enter id: </label><input id='id' type='number'><button id='deleteSubmit'>delete</button></form></div>"
				);
			});
			$(document).on('click','#Submit',function(e){
				e.preventDefault();
				var formData = {
				  "id": $("#id").val(),
				  "Name": $("#Name").val(),
				  "Email": $("#Email").val(),
				  "Address": $("#Address").val(),
				};
					
				$.ajax({
					type:"POST",
					url:"insert.php",
					data: formData,
					type:"POST",
					success:function(data){
						$("#main").html(data);
					}
				});
			});	


			$(document).on('click','#updateSubmit',function(e){
				e.preventDefault();
				var formData = {
				  "id": $("#id").val(),
				  "Name": $("#Name").val(),
				  "Email": $("#Email").val(),
				  "Address": $("#Address").val(),
				};
					
				$.ajax({
					type:"POST",
					url:"updateAdmin.php",
					data: formData,
					type:"POST",
					success:function(data){
						$("#main").html(data);
					}
				});
			});
			
			$(document).on('click','#deleteSubmit',function(e){
				e.preventDefault();
				var formData = {
				  "id": $("#id").val(),
				  "Name": $("#Name").val(),
				  "Email": $("#Email").val(),
				  "Address": $("#Address").val(),
				};
					
				$.ajax({
					type:"POST",
					url:"delete.php",
					data: formData,
					type:"POST",
					success:function(data){
						$("#main").html(data);
					}
				});
			});
			
		});
	</script>
	</body>
</html>