<?php
include '../View/LogIn.php';
$lfl=fopen("Log_Details.txt","a") or die("Unable to open the file");
$txt1=$_POST["uname"];
fwrite($lfl, $txt1);
fclose($lfl);
?>