<head>
	<link rel="stylesheet" href="after-login.css">
</head>
<body>
<button id="log-out"><a href="log5.php">Logout</a></button>
<button id="log-out"><a href="complain.php" style="color:red;">Complain!</a></button>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname="labtask";

$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
	
	{
	
	$q="SELECT * from passenger_information";
	$result=$conn->query($q);
	$output='<table border="1" width=100%><tr><th>Name</th><th>Email</th><th>User Name</th><th>Password</th><th>Confirm Password</th><th>DOB</th></tr>';
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			$output.= "<tr><td>{$row["Name"]}</td><td>{$row["Email"]}</td><td>{$row["User Name"]}</td><td>{$row["Password"]}</td><td>{$row["Confirm Password"]}</td><td>{$row["DOB"]}</td></tr>";
		}
		$output.='</table>';
	}
	else
		echo "O results";
	
	
}
$conn->close();
echo $output;
?>
</body>