
<html>
    <head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
            integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="login.css">
        <title>Log In</title>
    </head>

    <body>
	
        <div class="container">
            <div class="login-details">
                <div class="header">
                    <h2>Log In</h2>
                </div>
                <form action="info.php">
                    <div class="username">
                        <label for="username">Username<span>*</span></label>
                        <input type="text" id="username" name="" placeholder="Username" required>
                        <i class="fa-solid fa-circle-check"></i>
                        <i class="fa-solid fa-circle-exclamation"></i>
                    </div>
                    <div class="password">
                        <label for="password">Password<span>*</span></label>
                        <input type="password" id="password" name="" placeholder="password" required>
                        <i class="fa-solid fa-circle-check"></i>
                        <i class="fa-solid fa-circle-exclamation"></i>
                    </div>
                    <button type="submit">Log In</button>
                </form>
            </div>
            <div class="login-img">
                <img src="images/login-image-2.jpg" alt="login">
            </div>
        </div>
    </body>
</html>