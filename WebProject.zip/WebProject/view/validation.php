<?php
"../Model/Infor.json";
//include "Login.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] === "POST") {
  
    $username = $_POST['uname'];
    $password = $_POST['pass'];

    /*if (empty($username) or empty($password)) {
        // $_SESSION['errorMsg'] = "Please fill up the form properly";
        header("Location: LogIn.php?errorMsg='Please fill up the form properly'");
        
    }
   
    else {*/
        $_SESSION['uname'] = $username;
        $_SESSION['pass']=$password;
        $jsondata=file_get_contents("..Air/Model/Infor.json");
    $json=json_decode($jsondata,true);
    //echo $json['books'][0]['author'];
    foreach($json['Login'] as $b)
    {
       if($b['user']==$_SESSION['uname'] && $b['pw']==$_SESSION['pass'])
       {
        header('Location: info.php');
       }
       else
       {
        header("Location: Login.php?errorMsg='Please check username or password'");
       }
    }	
       // header('Location: Ppage.php');
    
    
}

?>