<html>
<body id="body">

<?php
$servername="localhost";
$username="root";
$password="";
$dbname="labtask";
$conn=new mysqli($servername,$username,$password,$dbname);

if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
{
	$q='Update Admin set Name="'.$_POST["Name"].'", Email="'.$_POST["Email"].'", Address="'.$_POST["Address"].'" where id="'.$_POST["id"].'"';
	$conn->query($q);
	
	$q="SELECT * from Admin";
	$result=$conn->query($q);
	$output='<table border="1" width=100%><tr><th>id</th><th>Name</th><th>Email</th><th>Address</th></tr>';
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			$output.= "<tr><td>{$row["id"]}</td><td>{$row["Name"]}</td><td>{$row["Email"]}</td><td>{$row["Address"]}</td></tr>";
		}
		$output.='</table>';
	}
	else
		echo "O results";
	
	
}
$conn->close();
echo $output;
?>