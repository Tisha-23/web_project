<?php
include '../controller/viewProfileCheck.php';

 ?>

<html>
<head>
	<title>Profile</title>
</head>

<table border="0" width="100%" height="100px">
  <tr>
   
    <td align="left"> <h1 style="color:blue">Admin information</h1></td>
    <td align="right">
      <h3>
        <a href="../view/log5.php"> Logout </a>
      </h3>
    </td>
  </tr>
</table>
<hr>

<!-- <center style="color:white">
  <h2><?php echo "Welcome ".$_SESSION['username']; ?></h2>
</center> -->
</div>


<body>
<!-- <table border="0" width="100%" height="100px">
  <tr>
    <td align="right">
      <h3>
        <a href="../controller/logout.php"> Logout </a>
      </h3>
    </td>
  </tr>
</table> -->




<table border="0" width="100%" height="100px">

  <tr>
    <td align="center"><b>Name:</b></td>
    <td width="50px"></td>
    <td align="center"><?php echo $_SESSION['name']  ?></td>

  </tr>
  <tr>
    <td colspan="3"><hr></td>
  </tr>
  <tr>
    <td align="center"><b>User Name:</b></td>
    <td width="50px"></td>
    <td align="center"><?php echo $_SESSION['username']  ?></td>
  </tr>
  <tr>
    <td colspan="3"><hr></td>
  </tr>
  <tr>
    <td align="center"><b>Email:</b></td>
    <td width="100px"></td>
    <td align="center"><?php echo $_SESSION['email'] ?></td>
  </tr>
  <tr>
    <td colspan="3"><hr></td>
  </tr>
  <tr>
    <td align="center"><b>Gender:</b></td>
    <td width="50px"></td>
    <td align="center"><?php echo $_SESSION['gender']  ?></td>
  </tr>
  <tr>
    <td colspan="3"><hr></td>
  </tr>
  <tr>
    <td align="center"><b>Date of Birth:</b></td>
    <td width="50px"></td>
    <td align="center"><?php echo $_SESSION['dob']  ?></td>
  </tr>
  <tr>
    <td colspan="3"><hr></td>
  </tr>



</table>
</body>
</html>
