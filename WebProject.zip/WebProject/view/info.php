
<!-- <html>
<head>
	
</head>
<body style="
background-image: url('airlines.jpg');
			background-repeat:no-repeat; 
			background-position:center;
			background-size: cover;
			position:relative;
			min-height: 100vh;
			width: 100%;">
    <center> <h1 style="color:rgb(40,29,14);">Welcome to MSTS Airline</center>
  

   <br>


<br>
<center><button type="submit"><a href="viewProfile.php"><h1>Admin</h1></a></button></center><br>
<center><button type="submit"><a href="pilot.php"><h1>Pilot</h1></a></button></center><br>
<center><button type="submit"><a href="air hostess.php"><h1>Air hostess</h1></a></button></center><br>
<center><button type="submit"><a href="passenger.php"><h1>Passenger</h1></a></button></center><br>
<br><br>

</div>
</body>
</html> -->
<html>
<head>
	<style>
	body{
			  display: flex;
			  justify-content: center;
			  align-items: center;
			  height: 98vh;
			  flex-direction: column;
			  background-image: linear-gradient(rgb(103 78 78 / 45%), rgb(24 13 13 / 56%)),
    url(airline.jpg);
			  background-position: center;
			  background-repeat: no-repeat;
			  background-size: cover;
		}
		h1{
    color: #fff;
    font-size: 50px;
}
		h2{}
		.options{}
		.single-options{
    background: #fff;
    text-align: center;
    margin: 15px 0px;
    border-radius: 10px;
}
		button{
    border: none;
    background: none;
}
		a{
    display: block;
    padding: 10px 20px;
    text-decoration: none;
    color: #000;

}
	</style>
	
</head>
<body>
	<h1>Welcome to MSTS Airline</h1>
		<div class="options">
			<div class="single-options">
			<button type="submit"><a href="labtask.php"><h2>Admin</h2></a></button>

			</div>
			<div class="single-options">
				<button type="submit"><a href="pilot.php"><h2>Pilot</h2></a></button>
			</div>
			<div class="single-options">
				<button type="submit"><a href="airHostess.php"><h2>Air hostess</h2></a></button>
			</div>
			<div class="single-options">
				<button type="submit"><a href="passengerInfo.php"><h2>Passenger</h2></a></button>
			</div>
		</div>
</body>
</html>