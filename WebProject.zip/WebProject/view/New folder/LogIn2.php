
<div style="background-image: url('2ndpage.jpg'); background repeat:no-repeat; height: 800px;">
    <center> <h1 style="color:rgb(40,29,14);">Welcome to MSTS Airline</center>
  

   <br>


<br>
<center><button type="submit" style="background-image:url('lin.jpg'); height: 75px; width: 150px;"></button></center><br>

<center><button type="submit" style="background-image:url('Hp.jpg'); height: 75px; width: 150px;"></button></center><br>

<center><button type="submit" style="background-image:url('lin.jpg'); height: 75px; width: 150px;"></button></center><br>

<center><button type="submit" style="background-image:url('Hp.jpg'); height: 75px; width: 150px;"></button></center><br><br><br>

</div>
