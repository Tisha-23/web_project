<?php
$servername="localhost";
$username="root";
$password="";
$dbname="labtask";

$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error)
{
	die("Connection failed:".$conn->connect_error);
}
else
	
	{
	
	$q="SELECT * from passenger";
	$result=$conn->query($q);
	$output='<table border="1" width=100%><tr><th>name</th><th>email</th><th>contact_number</th><th>flight_time</th></tr>';
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			$output.= "<tr><td>{$row["name"]}</td><td>{$row["email"]}</td><td>{$row["contact_number"]}</td><td>{$row["flight_time"]}</td></tr>";
		}
		$output.='</table>';
	}
	else
		echo "O results";
	
	
}
$conn->close();
echo $output;
?>